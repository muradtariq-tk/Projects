#include <iostream>
#include <iomanip>
#include <algorithm>
#include <cmath>
#include <vector>
using namespace std;
/*
7325189087
5
it
your
reality
real
our
4294967296
5
it
your
reality
real
our
-1
*/

bool check(int n, char character) {

}
int main() {
    string num, word;
    vector<string> v;
    v.push_back('lol');
    int c;
    cout << v[0];
    cin >> num >> c;
    /*for(int i = 0; i < c; ++i) {
        while(cin.get() =! -1) {
            cout << 'lol';
        }
        //v.push_back(word);
    }*/
}
